﻿using System;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Harjoitustyo_LaskutusApp
{

    public partial class PaivitaTuote : Window
    {
        public PaivitaTuote(Tuote tuote)
        {
            InitializeComponent();

            // Asetetaan DataContext tuote-olion mukaan, jotta ikkunan elementit saavat oikeat sidokset.
            this.DataContext = tuote;
        }

        /// <summary>
        /// Painikkeen kuuntelija tuotteen päivittämistä varten.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PaivitaValittuTuote(object sender, RoutedEventArgs e)
        {
            // Haetaan DataContextista muokattava tuote-olio.
            var tuote = (Tuote)this.DataContext;

            // Luodaan uusi Hallintatyokalut-olio.
            var tyokalu = new Hallintatyokalut();

            // Kutsutaan Hallintatyokalut-luokan MuokkaaTuotetta-metodia, joka tallentaa tuotteen tiedot tietokantaan.
            tyokalu.MuokkaaTuotetta(tuote);

            // Asetetaan DialogResult-arvoksi true, jolloin ikkuna suljetaan ja pääohjelma jatkaa suoritusta.
            DialogResult = true;
        }

        // apumuuttuja, tarkistusta varten onko desimaalierotin jo käytetty vai ei
        private bool isDecimalUsed = false;

        /// <summary>
        /// Tapahtumankuuntelija estä käyttäjää syöttämästä epäkelpoja merkkejä ja muuttaa desimaaliluvuksi pilkusta tai pisteestä riippumatta.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void YksikkohintaTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Tarkista, että syöte on numeroiden, pilkun tai pisteen yhdistelmä
            Regex regex = new Regex("[^0-9.,]+");
            if (regex.IsMatch(e.Text))
            {
                e.Handled = true;
            }
            else if (e.Text == ",")
            {
                // Jos käyttäjä syöttää pilkun, korvaa se pisteellä
                e.Handled = true;
                if (!isDecimalUsed)
                {
                    isDecimalUsed = true;
                    YksikkohintaTextBox.Text += ".";
                    YksikkohintaTextBox.CaretIndex = YksikkohintaTextBox.Text.Length;
                }
            }
            else if (e.Text == ".")
            {
                // Jos käyttäjä syöttää pisteen, tarkista, että se ei ole jo käytetty
                e.Handled = true;
                if (!isDecimalUsed)
                {
                    isDecimalUsed = true;
                    YksikkohintaTextBox.Text += ".";
                    YksikkohintaTextBox.CaretIndex = YksikkohintaTextBox.Text.Length;
                }
            }
            else
            {
                // Tarkista, että syöte sisältää vain yhden pilkun tai pisteen
                string text = YksikkohintaTextBox.Text + e.Text;
                int dotCount = text.Count(c => c == '.');
                int commaCount = text.Count(c => c == ',');
                if (dotCount + commaCount > 1)
                {
                    e.Handled = true;
                }
            }
        }


    }
}
