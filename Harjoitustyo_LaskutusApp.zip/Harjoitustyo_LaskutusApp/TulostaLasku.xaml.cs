﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Harjoitustyo_LaskutusApp
{
    /// <summary>
    /// Interaction logic for TulostaLasku.xaml
    /// </summary>
    public partial class TulostaLasku : Window
    {

        private Lasku lasku;
        public TulostaLasku(Lasku lasku)
        {
            InitializeComponent();

            // Asetetaan lasku-luokan jäsenmuuttuja lasku saadulla Lasku-oliolla.
            this.lasku = lasku;
            // Asetetaan DataContext laskuun, jotta sen ominaisuuksia voidaan käyttää XAML:issa.
            this.DataContext = lasku;
        }

        /// <summary>
        /// // Tapahtumankäsittelijä, joka sulkee ikkunan, kun Klikkaa-nappia painetaan.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
