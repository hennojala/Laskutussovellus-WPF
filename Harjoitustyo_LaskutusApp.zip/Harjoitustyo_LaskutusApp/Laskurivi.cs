﻿using System.Collections.ObjectModel;

namespace Harjoitustyo_LaskutusApp
{
    // Laskurivi-luokka, joka perii Tuote -luokan.
    public class Laskurivi: Tuote
    {
        public int RiviID { get; set; }
        public int LaskuID { get; set; }
        public int TuoteID { get; set; }
        public float KplHinta { get; set; }

        private float maara = 0;
        public float Maara
        {
            get
            {
                //palauttaa apumuuttujaan asetetun määrän.
                return maara;
            }
            set
            {
                maara = value;
            }
        }

        private float rivihinta;
        public float Rivihinta
        {
            get
            {
                // palauttaa maara*kplhinta
                return Maara * KplHinta;
            }
            set
            {
                rivihinta = value;
            }
        }

        public string TuoteNimi { get; set; }

        public ObservableCollection<Tuote> RiviTuote { get; set; }
        public Laskurivi()
        {
            // Alustetaan ominaisuudelle Rivituote uusi Tuote-ObservaCollection -lista.
            RiviTuote = new ObservableCollection<Tuote>();
        }
    }
}