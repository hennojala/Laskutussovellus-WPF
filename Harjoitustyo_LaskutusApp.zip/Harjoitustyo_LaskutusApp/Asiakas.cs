﻿namespace Harjoitustyo_LaskutusApp
{
    // Asiakas -luokka
    public class Asiakas
    {
        public int AsiakasID { get; set; }
        public string Sukunimi { get; set; }
        public string Etunimi { get; set; }
        public string Katu { get; set; }
        public int Postinumero { get; set; }
        public string Paikkakunta { get; set; }

        // Asiakkaalle luodaan myös Nimi -ominaisuus, joka sisältää etu- ja sukunimen.
        public string Nimi
        {
            get { return Sukunimi + " " + Etunimi; }
        }

    }
}