﻿using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace Harjoitustyo_LaskutusApp
{
    /// <summary>
    /// Interaction logic for PaivitaLasku.xaml
    /// </summary>
    public partial class PaivitaLasku : Window
    {

        private Hallintatyokalut tyokalu;
        private Lasku lasku;

        public PaivitaLasku(Lasku lasku)
        {
            InitializeComponent();

            // Luodaan uusi Hallintatyokalut-olio.
            tyokalu = new Hallintatyokalut();

            // Asetetaan laskuolio ja DataContext käyttöliittymän kontrolleille.
            this.lasku = lasku;
            this.DataContext = lasku;

            // Haetaan tuotteet Hallintatyokalut-olion avulla ja asetetaan ne ComboBoxin ItemsSourceksi.
            comtuote.ItemsSource = tyokalu.HaeTuotteet();
        }
        
        /// <summary>
        /// Tapahtumankäsittelijä dgrivit tapahtuman muokkaamista varten.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgRivit_PreparingCellForEdit(object sender, DataGridPreparingCellForEditEventArgs e)
        {
            if (e.Column is DataGridComboBoxColumn && e.EditingElement is ComboBox comboBox)
            {
                // Jos muokattavana oleva solu on DataGridComboBoxColumn ja sen EditingElement on ComboBox,
                // liitetään SelectionChanged-tapahtumankäsittelijä ComboBoxiin.
                comboBox.SelectionChanged += comtuote_SelectionChanged;
            }
        }

        /// <summary>
        /// Tapahtumankäsittelijä comtuoteboxin muutoksille
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comtuote_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
            {
                // Haetaan valittu LaskuRivi
                Laskurivi valittuRivi = dgRivit.SelectedItem as Laskurivi;

                // Tallennetaan valitun tuotteen tiedot valitun LaskuRivin TuoteID- ja KplHinta-ominaisuuksiin
                Tuote valittuTuote = e.AddedItems[0] as Tuote;

                if (valittuTuote != null)
                {
                    Tuote uusituote = tyokalu.HaeTuote(valittuTuote.TuoteNimi);

                    // Tarkistetaan, onko valittu tuote jo lisätty laskulle
                    var joLisatty = lasku.LaskuRivit.Any(lr => lr.TuoteID == uusituote.TuoteID);

                    if (joLisatty)
                    {
                        MessageBox.Show("Valittu tuote on jo lisätty laskulle.", "Virhe", MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }
                    else
                    {
                        valittuRivi.TuoteID = uusituote.TuoteID;
                        valittuRivi.KplHinta = uusituote.KplHinta;
                        valittuRivi.TuoteNimi = uusituote.TuoteNimi;
                    }
                }
                // Tallennetaan muokkaukset ennen DataGridin päivittämistä
                dgRivit.CommitEdit();
            }
        }

        /// <summary>
        /// Tapahtumankäsittelijä dgrivit tapahtuman päättymiselle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgRivit_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.Column is DataGridComboBoxColumn && e.EditingElement is ComboBox comboBox)
            {
                // Jos muokattavana oleva solu on DataGridComboBoxColumn ja sen EditingElement on ComboBox,
                // poistetaan SelectionChanged-tapahtumankäsittelijä ComboBoxista.
                comboBox.SelectionChanged -= comtuote_SelectionChanged;

                // Päivitetään lasku ja sen DataGrid dgRivit muokkausten jälkeen.
                PaivitaValittuLasku(null, null);
            }
        }

        /// <summary>
        /// Painikkeen kuuntelija laskun tallentamista varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TallennaValittuLasku(object sender, RoutedEventArgs e)
        {
            // Tallennetaan laskun tiedot tietokantaan
            tyokalu.MuokkaaLaskua(lasku);

            // Haetaan tallennetun laskun tiedot tietokannasta ja päivitetään ne näytölle
            lasku = tyokalu.HaeLaskuIDlla(lasku.LaskuID);
            this.DataContext = lasku;

            // Näytetään käyttäjälle ilmoitus tallennetusta laskusta
            MessageBox.Show("Laskun tiedot tallennettu järjestelmään!");
            DialogResult = true;

        }

        /// <summary>
        /// Painikkeen kuuntelija, joka poistaa valitun rivin laskulta
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PoistaRivi_Click(object sender, RoutedEventArgs e)
        {
            // Haetaan valittu rivi DataGridistä.
            Laskurivi valittuRivi = dgRivit.SelectedItem as Laskurivi;

            if (valittuRivi != null)
            {
                // Kysytään varmistus käyttäjältä.
                var result = MessageBox.Show("Haluatko varmasti poistaa valitun rivin järjestelmästä?", "Varoitus", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    // Kutsutaan Hallintatyokalut-olion metodia, joka poistaa rivin.
                    tyokalu.PoistaRivi(valittuRivi);
                    // Päivitetään laskun tiedot.
                    PaivitaValittuLasku(null, null);
                }
            }
        }

        /// <summary>
        /// Painikkeen kuuntelija, joka päivittaa valitun laskun
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PaivitaValittuLasku(object sender, RoutedEventArgs e)
        {
            // Kutsutaan Hallintatyokalut-olion metodia, joka päivittää laskutietoja.
            tyokalu.MuokkaaLaskua(lasku);

            // Haetaan päivitetty laskuolio ja asetetaan se DataContextiksi sekä DataGridille että tekstikentälle.
            lasku = tyokalu.HaeLaskuIDlla(lasku.LaskuID);
            dgRivit.DataContext = lasku;
            txtYhteensa.DataContext = lasku;

            //Päivitetään DataGridin näkymä.
            dgRivit.Items.Refresh();
        }

        /// <summary>
        /// Tarkitaa että postinumero voi olla vain kokonaisluku
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PostinumeroTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Tarkista, onko syöte kokonaisluku
            if (!int.TryParse(e.Text, out int result))
            {
                // Jos ei ole, estä tekstin syöttö
                e.Handled = true;
            }
        }

    }
}