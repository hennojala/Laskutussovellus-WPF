﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Harjoitustyo_LaskutusApp
{
    /// <summary>
    /// Interaction logic for LisaaUusiLasku.xaml
    /// </summary>
    public partial class LisaaUusiLasku : Window
    {
        // Luodaan uusi Lasku-olio
        Lasku lasku;
        // Luodaan Hallintatyökalut-olio
        private Hallintatyokalut tyokalu;

        public LisaaUusiLasku()
        {

            // Luodaan uusi käyttöliittymäikkuna
            InitializeComponent();

            // Luodaan uusi Hallintatyökalut-olio
            tyokalu = new Hallintatyokalut();

            // Luodaan uusi Lasku-olio
            Lasku uusilasku = new Lasku();
            lasku = uusilasku;

            // Ladataan asiakkaat ComboBoxiin
            comasnimi.ItemsSource = tyokalu.HaeAsiakkaat();
            comasnimi.SelectionChanged += Comasnimi_SelectionChanged;
        }

        private void Comasnimi_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            // Tarkistetaan onko ComboBoxiin valittu mitään
            if (comasnimi.SelectedItem != null)
            {
                // Valitaan ComboBoxista valittu Asiakas-olio
                var valittuAsiakas = (Asiakas)comasnimi.SelectedItem;
                // Asetetaan Asiakas-olion tiedot Asiakas-tiedot ryhmälaatikkoon
                astiedot.DataContext = valittuAsiakas;

                // Luodaan uusi ObservableCollection ja lisätään siihen valittu Asiakas-olio
                ObservableCollection<Asiakas> asiakasLista = new ObservableCollection<Asiakas>();
                asiakasLista.Add(valittuAsiakas);

                // Asetetaan Lasku-olion AsiakasTieto-kenttään asiakasLista
                lasku.AsiakasTieto = asiakasLista;

                // Asetetaan Lasku-olion AsiakasID-kenttään ensimmäisen (ja ainoan) Asiakas-olion AsiakasID
                lasku.AsiakasID = asiakasLista[0].AsiakasID;
            }
        }

        /// <summary>
        /// Tapahtumankuuntelija painikkelle asiakkaan lisäämistä varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LisaaAsiakas(object sender, RoutedEventArgs e)
        {
            // Luodaan uusi LisaaUusiAsiakas -ikkuna
            LisaaUusiAsiakas lisaaUusiAsiakas = new LisaaUusiAsiakas();
            // Avataan LisaaUusiAsiakas -ikkuna ja tallennetaan sen paluuarvo arvo-muuttujaan
            var arvo = lisaaUusiAsiakas.ShowDialog();

            // Tarkistetaan onko paluuarvo true
            if (arvo == true)
            {
                // Päivitetään asiakkaat ComboBoxiin
                comasnimi.ItemsSource = tyokalu.HaeAsiakkaat();

                // Asetetaan Lasku-olion LaskunAsiakas-kenttään viimeisin asiakas
                lasku.LaskunAsiakas = tyokalu.HaeAsiakkaat().Last();

                // Asetetaan Asiakas-tiedot ryhmälaatikkoon Lasku-olion LaskunAsiakas-kentän arvo
                astiedot.DataContext = lasku.LaskunAsiakas;

                //// Asetetaan Lasku-AsiakasID kohtaan laskun.LaskunAsiakas AsiakasID
                lasku.AsiakasID = lasku.LaskunAsiakas.AsiakasID;

            }
        }

        /// <summary>
        /// Painikkeen kuuntelija jatkamista seuraavaan ikkunaan vartan. Lisää myös jo alustavan laskun järjestelmään
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Jatka(object sender, RoutedEventArgs e)
        {
            //jos laskulle on määritelty asiakas.
            if (lasku.AsiakasID != 0)
            {
                //Lisätään lasku tietokantaan
                tyokalu.LisaaLasku(lasku);

                //Haetaan lisätty lasku tietokannasta ja asetetaan se nykyiseksi laskuksi
                lasku = tyokalu.HaeKaikkiLaskut().Last();


                //Avataan laskun muokkausikkuna
                PaivitaLasku paivitalas = new PaivitaLasku(lasku);
                paivitalas.ShowDialog();

                //Haetaan kaikki laskut uudestaan päivitetyn laskun varalta
                tyokalu.HaeKaikkiLaskut();
                //Asetetaan dialogin tulos todeksi eli käyttäjä on valinnut Jatka-painikkeen
                DialogResult = true;

            }
        }

        /// <summary>
        /// painikkeen tapahtumankuuntelija peruutusta varten jollon ikkuna sulkeutuu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Peruuta(object sender, RoutedEventArgs e)
        {
            //Asetetaan dialogin tulos todeksi eli käyttäjä on valinnut Peruuta-painikkeen
            DialogResult = true;
        }

    }
}
