﻿using System.Windows;

namespace Harjoitustyo_LaskutusApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private Hallintatyokalut tyokalut;

        public MainWindow()
        {
            InitializeComponent();

            // Luodaan tietokanta, taulut ja data kutsutamalla metodeita

            tyokalut = new Hallintatyokalut();
            tyokalut.LuoLaskutusDb();
            tyokalut.LuoAsiakasTaulu();
            tyokalut.LuoTuoteTaulu();
            tyokalut.LuoLaskuTaulu();
            tyokalut.LuoLaskuRiviTaulu();
            tyokalut.LuoData();
        }

        /// <summary>
        /// Tapahtumankuuntelija luo uuden HaeKaikkiLaskut -olion ja avaa sen.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void HaeKaikkiLaskut(object sender, RoutedEventArgs e)
        {
            HaeKaikkiLaskut kaikkilaskut = new HaeKaikkiLaskut();
            kaikkilaskut.ShowDialog();
        }

        /// <summary>
        /// Tapahtumankuuntelija luo uuden HaeKaikkiTuotteet -olion ja avaa sen.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void HaeKaikkiTuotteet(object sender, RoutedEventArgs e)
        {
            HaeKaikkiTuotteet tuotteetkaikki = new HaeKaikkiTuotteet();
            tuotteetkaikki.ShowDialog();
        }

        /// <summary>
        /// Tapahtumankuuntelija luo uuden HaeKaikkiAsiakkaat -olion ja avaa sen.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void HaeKaikkiAsiakkaat(object sender, RoutedEventArgs e)
        {
            HaeKaikkiAsiakkaat kaikkiAsiakkaat = new HaeKaikkiAsiakkaat();
            kaikkiAsiakkaat.ShowDialog();
        }

        /// <summary>
        /// Tapahtumankuuntelija painikkeelle ikkunan sulkemista varten.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Button_Click(object sender, RoutedEventArgs e)
        {
            // Sulkee ikkunan
            Close();
        }

    }
}