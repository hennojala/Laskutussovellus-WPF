﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace Harjoitustyo_LaskutusApp
{
    // Lasku -luokka
    public class Lasku
    {
        public int LaskuID { get; set; }
        public int AsiakasID { get; set; }
        public DateTime Paivamaara { get; set; }
        public DateTime Erapaiva { get; set; }
        public string Lisatiedot { get; set; }
        public float Yhteensa { get; set; }

        public ObservableCollection<Laskurivi> LaskuRivit { get; set; }
        public ObservableCollection<Asiakas> AsiakasTieto { get; set; }
        public ObservableCollection<Tuote> TuoteTieto { get; set; }
        public Asiakas LaskunAsiakas { get; set; }

        // Konstruktorissa asetetaan oletusarvot
        public Lasku()
        {
            // Oletus päivälle tämäpäivä ja eräpäivälle kaksi viikkoa tästä päivästä.
            Paivamaara = DateTime.Today;
            Erapaiva = DateTime.Now.AddDays(14);

            Lisatiedot = "";

            // Alustetaan ominaisuuksille Rivituote uusi Tuote-ObservaCollection -lista.
            LaskuRivit = new ObservableCollection<Laskurivi>();
            AsiakasTieto = new ObservableCollection<Asiakas>();
            TuoteTieto = new ObservableCollection<Tuote>();

            // Laskee laskun yhteissummaa kutsuen metodia
            LaskuRivit.CollectionChanged += LaskeYhteensa;

        }

        //Laskee laskun yhteissummaa.
        private void LaskeYhteensa(object sender, NotifyCollectionChangedEventArgs e)
        {
            float summa = 0;

            foreach (Laskurivi laskurivi in LaskuRivit)
            {
                summa += laskurivi.Rivihinta;

            }

            Yhteensa = summa;
        }
    }
}