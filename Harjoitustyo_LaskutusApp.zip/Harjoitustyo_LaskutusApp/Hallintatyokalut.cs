﻿using MySqlConnector;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Security.Cryptography.Pkcs;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls.Primitives;

namespace Harjoitustyo_LaskutusApp
{
    /// <summary>
    /// Luokassa on "tyokalun" avulla käytettyjä metodeita, jotka käyttävät yhteyttä tietokantaan.
    /// </summary>
    public class Hallintatyokalut
    {

        // vakioarvo jossa on määritetty käytettävän tietokannan tiedot. Lisää tiedot.
        private const string local = @"Server=""; Port=""; User ID=""; Pwd="";";
        private const string localWithDb = @"Server=""; Port=""; User ID=""; Pwd=""; Database=laskutusapp;";

        // Luo tietokannan
        public void LuoLaskutusDb()
        {

            using (MySqlConnection conn = new MySqlConnection(local))
            {
                conn.Open();

                // Jos tietokanta löytyy jo ennestään, poistetaan vanha
                MySqlCommand cmd = new MySqlCommand("DROP DATABASE IF EXISTS LaskutusApp", conn);
                cmd.ExecuteNonQuery();

                // Luo tietokanta
                cmd = new MySqlCommand("CREATE DATABASE LaskutusApp", conn);
                cmd.ExecuteNonQuery();
            }
        }

        // Luo taulu laskuille
        public void LuoLaskuTaulu()
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                // LASKUTAULU
                string createTables =

                "CREATE TABLE Lasku (" +
                "LaskuID INT NOT NULL AUTO_INCREMENT," +
                "Paivamaara DATE NOT NULL," +
                "Erapaiva DATE NOT NULL," +
                "AsiakasID INT NOT NULL," +
                "Lisatiedot VARCHAR(100) NOT NULL," +
                "PRIMARY KEY (LaskuID)," +
                "FOREIGN KEY (AsiakasID) REFERENCES Asiakas(AsiakasID)" +
                ");";

                MySqlCommand cmd = new MySqlCommand(createTables, conn);
                cmd.ExecuteNonQuery();

            }
        }

        // Luo taulu tuotteille
        public void LuoTuoteTaulu()
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                string createTable = "CREATE TABLE Tuote (" +
                          "TuoteID INT NOT NULL AUTO_INCREMENT," +
                          "Tuotenimi VARCHAR(30) NOT NULL," +
                          "Yksikko VARCHAR(10) NOT NULL," +
                          "KplHinta FLOAT NOT NULL," +
                          "PRIMARY KEY (TuoteID)" +
                          ");";

                MySqlCommand cmd = new MySqlCommand(createTable, conn);
                cmd.ExecuteNonQuery();
            }
        }

        // Luo taulu Asiakastiedoille
        public void LuoAsiakasTaulu()
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                string createTable = "CREATE TABLE Asiakas (" +
                          "AsiakasID INT AUTO_INCREMENT," +
                          "Sukunimi VARCHAR(40) NOT NULL," +
                          "Etunimi VARCHAR(30) NOT NULL," +
                          "Katu VARCHAR(40) NOT NULL," +
                          "Postinumero INT NOT NULL," +
                          "Paikkakunta VARCHAR(40) NOT NULL," +
                          "PRIMARY KEY (AsiakasID)" +
                          ")";

                MySqlCommand cmd = new MySqlCommand(createTable, conn);
                cmd.ExecuteNonQuery();
            }
        }

        // Luo taulu laskukriveille
        public void LuoLaskuRiviTaulu()
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                string createTable = "CREATE TABLE LaskuRivi (" +
                    "RiviID INT NOT NULL AUTO_INCREMENT," +
                    "Maara FLOAT NOT NULL," +
                    "LaskuID INT NOT NULL," +
                    "TuoteID INT NOT NULL," +
                    "Rivihinta FLOAT," +
                    "PRIMARY KEY (RiviID)," +
                    "FOREIGN KEY (TuoteID) REFERENCES Tuote(TuoteID)," +
                    "FOREIGN KEY (LaskuID) REFERENCES Lasku(LaskuID)," +
                    "UNIQUE (TuoteID, LaskuID)" + ");";

                MySqlCommand cmd = new MySqlCommand(createTable, conn);
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Luodaan pohjadataa ohjelmaan
        /// </summary>
        public void LuoData()
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                // SYÖTETÄÄN TIETOKANTAAN ASIAKASTIETOJA
                string as1 = "INSERT INTO asiakas VALUES(1000,'Meikäläinen','Maija','Kotikatu 5', 43434,'Kotila');";
                string as2 = "INSERT INTO asiakas (sukunimi, etunimi, katu, postinumero, paikkakunta)" +
                                "VALUES" +
                                        "('Virtanen', 'Pauli', 'Järvikuja 220', 17850, 'Järvelä')," +
                                        "('Aaltonen', 'Roosa', 'Koivukatu', 33320, 'Puustila')," +
                                        "('Hiirulainen', 'Mikki', 'Ankkakatu 7', 12121, 'Linnala')," +
                                        "('Mikkonen', 'Kati', 'Palokuja 555', 78770, 'Palola')," +
                                        "('Heikura', 'Lotta', 'Mutkatie 54', 17850, 'Järvelä')," +
                                        "('Huovinen', 'Petteri', 'Loistetie', 33320, 'Puustila')," +
                                        "('Uhmalainen', 'Hille', 'Järvikuja 111', 17850, 'Järvelä')," +
                                        "('Kohonen', 'Astrid', 'Runopolku 2', 78770, 'Palola')," +
                                        "('Haukkanen', 'Niilo', 'Rosterimäki 1210', 22547, 'Rossila')," +
                                        "('Haukkanen', 'Netta', 'Rsterikuja 32', 22547, 'Rossila')," +
                                        "('Rosalainen', 'Riitta', 'Joenmutka 88', 17550, 'Jokila');";


                // SYÖTETÄÄN TIETOKANTAAN LASKUJA
                string lasku1 = "INSERT INTO lasku VALUES(10000, '2022-02-01', '2022-04-01', 1002, 'Kylpyhuoneremontti');";
                string lasku2 = "INSERT INTO lasku(Paivamaara, Erapaiva, AsiakasID, Lisatiedot)" +
                                "VALUES('2022-08-07', '2022-10-07', 1011, 'Kattoremontti')," +
                                        "('2020-09-07', '2020-11-07', 1009, 'Silikonien vaihto')," +
                                        "('2018-12-04', '2018-12-16', 1004, 'Saunan rakennus')," +
                                        "('2015-06-20', '2015-07-20', 1000, 'Keittön saneeraus')," +
                                        "('2019-12-04', '2019-12-24', 1001, 'Laatoitus')," +
                                        "('2022-01-07', '2022-01-21', 1002, 'Portaiden kunnostus')," +
                                        "('2018-12-07', '2018-12-18', 1003, 'Lauteiden vaihto')," +
                                        "('2019-06-30', '2019-07-30', 1000, 'Ikkunoiden vaihto')," +
                                        "('2015-09-30', '2015-10-30', 1005, 'Korjaustyö')," +
                                        "('2022-01-23', '2022-02-23', 1004, 'Vajan rakennus');";


                // SYÖTETÄÄN TIETOKANTAAN TUOTTEITA
                string tuote1 = "INSERT INTO tuote VALUES(100, 'Silikoni', 'l', 13.50);";
                string tuote2 = "INSERT INTO tuote(Tuotenimi, Yksikko, KplHinta)" +
                                "VALUES('Kattopaneeli', 'm', 6.75)," +
                                        "('Maali', 'l', 23.35)," +
                                        "('Ruuvi', 'pkt', 10.20)," +
                                        "('Työ','h', 20.50)," +
                                        "('Lankku','m',5.50)," +
                                        "('Saunapaneeli', 'm', 14.20)," +
                                        "('Lakka','l', 28.50)," +
                                        "('Saumausaine','kg',9.50)," +
                                        "('Tapetti','rulla', 28.50)," +
                                        "('Laatat','kpl', 18.50)," +
                                        "('Suojausaine', 'ml', 30.50)," +
                                        "('Laasti', 'kg', 4.40);";


                // SYÖTETÄÄN TIETOKANTAAN LASKURIVEJÄ
                string rivi1 = "INSERT INTO laskurivi VALUES(1, 3, 10001, 100, NULL);";
                string rivi2 = "INSERT INTO laskurivi(maara, laskuid, tuoteid)" +
                                        "VALUES(4, 10002, 100)," +
                                        "(7, 10001, 102)," +
                                        "(8, 10000, 104)," +
                                        "(40, 10002, 103)," +
                                        "(8, 10003, 103)," +
                                        "(7, 10001, 107)," +
                                        "(8, 10004, 104)," +
                                        "(10, 10005, 105)," +
                                        "(1, 10006, 111)," +
                                        "(8, 10008, 109)," +
                                        "(9, 10009, 107)," +
                                        "(1, 10010, 110)," +
                                        "(2, 10008, 103)," +
                                        "(5, 10005, 104)," +
                                        "(30, 10010, 105)," +
                                        "(4, 10006, 101)," +
                                        "(12, 10008, 104)," +
                                        "(8, 10007, 107)," +
                                        "(9, 10010, 111)," +
                                        "(7, 10001, 108)," +
                                        "(1, 10004, 110)," +
                                        "(42, 10005, 106)," +
                                        "(13, 10006, 105)," +
                                        "(2, 10008, 105)," +
                                        "(4, 10009, 105)," +
                                        "(1, 10010, 101)," +
                                        "(2, 10010, 109)," +
                                        "(4.5, 10010, 100)," +
                                        "(21, 10010, 103);";


                MySqlCommand cmd = new MySqlCommand(as1, conn);
                cmd.ExecuteNonQuery();
                cmd = new MySqlCommand(as2, conn);
                cmd.ExecuteNonQuery();
                cmd = new MySqlCommand(lasku1, conn);
                cmd.ExecuteNonQuery();
                cmd = new MySqlCommand(lasku2, conn);
                cmd.ExecuteNonQuery();
                cmd = new MySqlCommand(tuote1, conn);
                cmd.ExecuteNonQuery();
                cmd = new MySqlCommand(tuote2, conn);
                cmd.ExecuteNonQuery();
                cmd = new MySqlCommand(rivi1, conn);
                cmd.ExecuteNonQuery();
                cmd = new MySqlCommand(rivi2, conn);
                cmd.ExecuteNonQuery();


            }
        }

        /// <summary>
        /// Metodi hakee kaikki asiakkaat tietokannasta ja palauttaa ne.
        /// </summary>
        /// <returns></returns>
        public ObservableCollection<Asiakas> HaeAsiakkaat()
        {
            var asiakkaat = new ObservableCollection<Asiakas>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                MySqlCommand cmd = new MySqlCommand("SELECT asiakasID, sukunimi, etunimi, katu, postinumero, paikkakunta FROM Asiakas", conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    asiakkaat.Add(new Asiakas
                    {
                        AsiakasID = dr.GetInt32("asiakasID"),
                        Sukunimi = dr.GetString("sukunimi"),
                        Etunimi = dr.GetString("etunimi"),
                        Katu = dr.GetString("katu"),
                        Postinumero = dr.GetInt32("postinumero"),
                        Paikkakunta = dr.GetString("paikkakunta")


                    });
                }
            }

            return asiakkaat;
        }

        /// <summary>
        /// Metodi hakee Asiakkaista yhden asiakkaan AsiaksID:n perusteella
        /// </summary>
        /// <param name="asiakasid"></param>
        /// <returns></returns>
        public Asiakas HaeAsiakasIDlla(int asiakasid)
        {
            Asiakas asiakas1 = null;

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                MySqlCommand cmd = new MySqlCommand("SELECT asiakasID, sukunimi, etunimi, katu, postinumero, paikkakunta FROM Asiakas WHERE AsiakasID=@AsiakasID", conn);
                cmd.Parameters.AddWithValue("@AsiakasID", asiakasid);

                var dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    asiakas1 = new Asiakas
                    {
                        AsiakasID = dr.GetInt32("asiakasID"),
                        Sukunimi = dr.GetString("sukunimi"),
                        Etunimi = dr.GetString("etunimi"),
                        Katu = dr.GetString("katu"),
                        Postinumero = dr.GetInt32("postinumero"),
                        Paikkakunta = dr.GetString("paikkakunta")
                    };
                }
            }

            return asiakas1;
        }

        /// <summary>
        /// Metodi Hakee laskulle asiakastiedot laskuid:n perusteella ja lisää laskulle Asiakastieto -ominaisuuteen kyseisen asiakkaan.
        /// </summary>
        /// <param name="uusilasku"></param>
        public void HaeAsiakas(Lasku uusilasku)
        {

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                MySqlCommand cmd = new MySqlCommand("SELECT * FROM asiakas a INNER JOIN lasku l ON a.AsiakasID = l.AsiakasID AND LaskuID = @LaskuID", conn);
                cmd.Parameters.AddWithValue("@LaskuID", uusilasku.LaskuID);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    uusilasku.AsiakasTieto.Add(new Asiakas
                    {
                        AsiakasID = dr.GetInt32("asiakasID"),
                        Sukunimi = dr.GetString("sukunimi"),
                        Etunimi = dr.GetString("etunimi"),
                        Katu = dr.GetString("katu"),
                        Postinumero = dr.GetInt32("postinumero"),
                        Paikkakunta = dr.GetString("paikkakunta")

                    });
                }
            }
        }

        /// <summary>
        /// Metodi lisää asiakkaan tietokantaan
        /// </summary>
        /// <param name="asiakas"></param>
        public void LisaaAsiakas(Asiakas asiakas)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("INSERT INTO Asiakas(sukunimi, etunimi, katu, postinumero, paikkakunta) VALUES (@sukunimi, @etunimi, @katu, @postinumero, @paikkakunta)", conn);

                cmd.Parameters.AddWithValue("@sukunimi", asiakas.Sukunimi);
                cmd.Parameters.AddWithValue("@etunimi", asiakas.Etunimi);
                cmd.Parameters.AddWithValue("@katu", asiakas.Katu);
                cmd.Parameters.AddWithValue("@postinumero", asiakas.Postinumero);
                cmd.Parameters.AddWithValue("@paikkakunta", asiakas.Paikkakunta);

                cmd.ExecuteNonQuery();
                MessageBox.Show($"Asiakas {asiakas.Etunimi} {asiakas.Sukunimi} lisätty järjestelmään!");

            }
        }

        /// <summary>
        ///  Metodi poistaa asiakkaan tietokannasta
        /// </summary>
        /// <param name="asiakas"></param>
        public void PoistaAsiakas(Asiakas asiakas)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("DELETE FROM Asiakas WHERE AsiakasID=@AsiakasID", conn);

                cmd.Parameters.AddWithValue("@AsiakasID", asiakas.AsiakasID);

                cmd.ExecuteNonQuery();

            }
        }

        /// <summary>
        ///  Metodi päivittää asiakkaan tiedot
        /// </summary>
        /// <param name="asiakas"></param>
        public void MuokkaaAsiakasta(Asiakas asiakas)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("UPDATE Asiakas SET sukunimi=@sukunimi, etunimi=@etunimi, katu=@katu, postinumero=@postinumero, paikkakunta=@paikkakunta WHERE AsiakasID=@AsiakasID", conn);

                cmd.Parameters.AddWithValue("@sukunimi", asiakas.Sukunimi);
                cmd.Parameters.AddWithValue("@etunimi", asiakas.Etunimi);
                cmd.Parameters.AddWithValue("@katu", asiakas.Katu);
                cmd.Parameters.AddWithValue("@postinumero", asiakas.Postinumero);
                cmd.Parameters.AddWithValue("@paikkakunta", asiakas.Paikkakunta);
                cmd.Parameters.AddWithValue("@AsiakasID", asiakas.AsiakasID);

                cmd.ExecuteNonQuery();

            }
        }

        /// <summary>
        /// Metodi hakee tietokannasta kaikki asiakkaan laskut ja ryhmittelee ne AsiakasID:lle.
        /// </summary>
        /// <returns></returns>
        public ObservableCollection<Lasku> HaeKaikkiLaskutAsID()
        {
            var laskut = new ObservableCollection<Lasku>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                MySqlCommand cmd = new MySqlCommand("SELECT LaskuID, Paivamaara, Erapaiva, AsiakasID, Lisatiedot FROM Lasku GROUP BY AsiakasID", conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    var uusilasku = new Lasku
                    {
                        LaskuID = dr.GetInt32("LaskuID"),
                        Paivamaara = dr.GetDateTime("Paivamaara"),
                        Erapaiva = dr.GetDateTime("Erapaiva"),
                        Lisatiedot = dr.GetString("Lisatiedot"),
                        AsiakasID = dr.GetInt32("AsiakasID")
                    };


                    HaeRivit(uusilasku);
                    HaeAsiakas(uusilasku);

                    laskut.Add(uusilasku);
                }
            }


            return laskut;
        }

        /// <summary>
        /// Metodi hakee kaikki laskut tietokannasta.
        /// </summary>
        /// <returns></returns>
        public ObservableCollection<Lasku> HaeKaikkiLaskut()
        {

            var laskut = new ObservableCollection<Lasku>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                MySqlCommand cmd = new MySqlCommand("SELECT LaskuID, Paivamaara, Erapaiva, AsiakasID, Lisatiedot FROM Lasku", conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    var uusilasku = new Lasku
                    {
                        LaskuID = dr.GetInt32("LaskuID"),
                        Paivamaara = dr.GetDateTime("Paivamaara"),
                        Erapaiva = dr.GetDateTime("Erapaiva"),
                        Lisatiedot = dr.GetString("Lisatiedot"),
                        AsiakasID = dr.GetInt32("AsiakasID")
                    };


                    HaeRivit(uusilasku);
                    HaeAsiakas(uusilasku);

                    laskut.Add(uusilasku);
                }
            }


            return laskut;
        }

        /// <summary>
        /// Metodi hakee kaikki kyseisen laskun laskurivit tietokannasta.
        /// </summary>
        /// <param name="uusilasku"></param>
        public void HaeRivit(Lasku uusilasku)
        {

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {

                conn.Open();

                MySqlCommand cmd = new MySqlCommand("SELECT * FROM laskurivi l INNER JOIN tuote t ON t.TuoteID = l.TuoteID AND LaskuID=@LaskuID", conn);
                cmd.Parameters.AddWithValue("@LaskuID", uusilasku.LaskuID);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    uusilasku.LaskuRivit.Add(new Laskurivi
                    {
                        LaskuID = dr.GetInt32("LaskuID"),
                        RiviID = dr.GetInt32("RiviID"),
                        Maara = dr.GetFloat("Maara"),
                        KplHinta = dr.GetFloat("KplHinta"),
                        TuoteNimi = dr.GetString("TuoteNimi"),
                        Yksikko = dr.GetString("Yksikko"),
                        TuoteID = dr.GetInt32("TuoteID"),
                        Rivihinta = dr.GetFloat("Maara") * dr.GetFloat("KplHinta")

                    }); ;
                }

            }
        }

        /// <summary>
        ///  Metodi hakee tietokannasta laskun id:n perusteella ja paluttaa laskun.
        /// </summary>
        /// <param name="laskuID"></param>
        /// <returns></returns>
        public Lasku HaeLaskuIDlla(int laskuID)
        {
            Lasku lasku = null;

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                MySqlCommand cmd = new MySqlCommand("SELECT LaskuID, Paivamaara, Erapaiva, AsiakasID, Lisatiedot FROM Lasku WHERE LaskuID=@LaskuID", conn);

                cmd.Parameters.AddWithValue("@LaskuID", laskuID);

                var dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    lasku = new Lasku
                    {
                        LaskuID = dr.GetInt32("LaskuID"),
                        Paivamaara = dr.GetDateTime("Paivamaara"),
                        Erapaiva = dr.GetDateTime("Erapaiva"),
                        Lisatiedot = dr.GetString("Lisatiedot"),
                        AsiakasID = dr.GetInt32("AsiakasID"),
                    };

                    HaeRivit(lasku);
                    HaeAsiakas(lasku);
                }
            }

            return lasku;
        }

        /// <summary>
        /// Metodi tallentaa laskun tietokantaan ja lisää sille rivit kutsumalla toista metodia.
        /// </summary>
        /// <param name="lasku"></param>
        public void TallennaLasku(Lasku lasku)
        {
            float summa = 0;

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("UPDATE Lasku SET Paivamaara=@Paivamaara, Erapaiva=@Erapaiva, Lisatiedot=@Lisatiedot, AsiakasID=@AsiakasID WHERE LaskuID=@LaskuID", conn);

                cmd.Parameters.AddWithValue("@paivamaara", lasku.Paivamaara);
                cmd.Parameters.AddWithValue("@erapaiva", lasku.Erapaiva);
                cmd.Parameters.AddWithValue("@Lisatiedot", lasku.Lisatiedot);
                cmd.Parameters.AddWithValue("@AsiakasID", lasku.AsiakasID);
                cmd.Parameters.AddWithValue("@LaskuID", lasku.LaskuID);
                cmd.ExecuteNonQuery();
            }
            Lasku uusilasku = HaeLaskutAsiakasIDlla(lasku.AsiakasID)[0];
            foreach (Laskurivi rivi in uusilasku.LaskuRivit)
            {
                LisaaRivi(rivi);
            }

            lasku.Yhteensa = summa;
        }

        /// <summary>
        /// Metodi hakee laskut asiakasID:lla ilman, että niitä on ryhmitelty AsiakasID:n tai muunkaan perusteella.
        /// </summary>
        /// <param name="asiakasID"></param>
        /// <returns></returns>
        public ObservableCollection<Lasku> HaeLaskutAsiakasIDlla(int asiakasID)
        {
            var laskut = new ObservableCollection<Lasku>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                MySqlCommand cmd = new MySqlCommand("SELECT LaskuID, Paivamaara, Erapaiva, AsiakasID, Lisatiedot FROM Lasku WHERE AsiakasID=@AsiakasID", conn);

                cmd.Parameters.AddWithValue("@AsiakasID", asiakasID);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    var lasku = new Lasku
                    {
                        LaskuID = dr.GetInt32("LaskuID"),
                        Paivamaara = dr.GetDateTime("Paivamaara"),
                        Erapaiva = dr.GetDateTime("Erapaiva"),
                        Lisatiedot = dr.GetString("Lisatiedot"),
                        AsiakasID = asiakasID
                    };

                    HaeRivit(lasku);
                    HaeAsiakas(lasku);
                    laskut.Add(lasku);
                }
            }

            return laskut;
        }

        /// <summary>
        /// Lisaa parametrinä saadun laskun tietokantaan.
        /// </summary>
        /// <param name="lasku"></param>
        public void LisaaLasku(Lasku lasku)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("INSERT INTO lasku (Paivamaara, Erapaiva, AsiakasID, Lisatiedot) VALUES(@Paivamaara, @Erapaiva, @AsiakasID, @Lisatiedot)", conn);

                cmd.Parameters.AddWithValue("@Paivamaara", lasku.Paivamaara);
                cmd.Parameters.AddWithValue("@Erapaiva", lasku.Erapaiva);
                cmd.Parameters.AddWithValue("@Lisatiedot", lasku.Lisatiedot);
                cmd.Parameters.AddWithValue("@AsiakasID", lasku.AsiakasID);
                cmd.ExecuteNonQuery();

                if (lasku.LaskuRivit.Count > 0)
                {
                    Lasku uusilasku = HaeLaskutAsiakasIDlla(lasku.AsiakasID)[0];
                    foreach (Laskurivi rivi in uusilasku.LaskuRivit)
                    {
                        LisaaRivi(rivi);
                    }
                }
            }
        }

        /// <summary>
        ///  Poistaa laskun tietokannasta
        /// </summary>
        /// <param name="lasku"></param>
        public void PoistaLasku(Lasku lasku)
        {
            foreach (Laskurivi rivi in lasku.LaskuRivit)
            {
                PoistaRivi(rivi);
            }

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();
                MySqlCommand cmi = new MySqlCommand("DELETE FROM Lasku WHERE laskuID=@LaskuID", conn);
                cmi.Parameters.AddWithValue("@LaskuID", lasku.LaskuID);
                cmi.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Muokkaa parametrinä saadun laskun ja sen oheisluokkien tiedot tietokantaan
        /// </summary>
        /// <param name="lasku"></param>
        public void MuokkaaLaskua(Lasku lasku)
        {

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("UPDATE Lasku SET Paivamaara=@Paivamaara, Erapaiva=@Erapaiva, AsiakasID=@AsiakasID, Lisatiedot=@Lisatiedot WHERE LaskuID=@LaskuID", conn);

                //PAIVITA LASKU
                cmd.Parameters.AddWithValue("@Paivamaara", lasku.Paivamaara);
                cmd.Parameters.AddWithValue("@Erapaiva", lasku.Erapaiva);
                cmd.Parameters.AddWithValue("@Lisatiedot", lasku.Lisatiedot);
                cmd.Parameters.AddWithValue("@AsiakasID", lasku.AsiakasID);
                cmd.Parameters.AddWithValue("@LaskuID", lasku.LaskuID);
                cmd.ExecuteNonQuery();


                MySqlCommand cma = new MySqlCommand("UPDATE Asiakas SET sukunimi=@sukunimi, etunimi=@etunimi, katu=@katu, postinumero=@postinumero, paikkakunta=@paikkakunta WHERE AsiakasID=@AsiakasID", conn);

                cma.Parameters.AddWithValue("@sukunimi", lasku.AsiakasTieto[0].Sukunimi);
                cma.Parameters.AddWithValue("@etunimi", lasku.AsiakasTieto[0].Etunimi);
                cma.Parameters.AddWithValue("@katu", lasku.AsiakasTieto[0].Katu);
                cma.Parameters.AddWithValue("@postinumero", lasku.AsiakasTieto[0].Postinumero);
                cma.Parameters.AddWithValue("@paikkakunta", lasku.AsiakasTieto[0].Paikkakunta);
                cma.Parameters.AddWithValue("@AsiakasID", lasku.AsiakasTieto[0].AsiakasID);

                cma.ExecuteNonQuery();


                foreach (var line in lasku.LaskuRivit)
                {

                    if (line.RiviID == 0)
                    {
                        // LISÄÄ RIVI JOS UUSI RIVI
                        MySqlCommand cmdIns = new MySqlCommand("INSERT INTO laskurivi (maara, laskuid, tuoteid, Rivihinta) VALUES(@maara, @laskuid, @tuoteid, @Rivihinta)", conn);
                        cmdIns.Parameters.AddWithValue("@maara", line.Maara);
                        cmdIns.Parameters.AddWithValue("@tuoteid", line.TuoteID);
                        cmdIns.Parameters.AddWithValue("@laskuid", lasku.LaskuID);
                        line.Rivihinta = line.KplHinta * line.Maara;
                        cmdIns.Parameters.AddWithValue("@Rivihinta", line.Rivihinta);

                        cmdIns.ExecuteNonQuery();
                    }

                    else
                    {
                        // PAIVITA LASKURIVI
                        MySqlCommand cmdUpd = new MySqlCommand("UPDATE laskurivi SET maara = @maara, tuoteid=@tuoteid, Rivihinta=@Rivihinta WHERE RiviID=@RiviID", conn);
                        cmdUpd.Parameters.AddWithValue("@maara", line.Maara);
                        cmdUpd.Parameters.AddWithValue("@tuoteid", line.TuoteID);
                        cmdUpd.Parameters.AddWithValue("@RiviID", line.RiviID);
                        float Rivihinta = line.KplHinta * line.Maara;
                        cmdUpd.Parameters.AddWithValue("@Rivihinta", Rivihinta);
                        cmdUpd.ExecuteNonQuery();
                    }
                }
            }
        }

        /// <summary>
        ///  Hakee kaikki tietokannan tuotteet ja palauttaa ne
        /// </summary>
        /// <returns></returns>
        public ObservableCollection<Tuote> HaeTuotteet()
        {
            var tuotteet = new ObservableCollection<Tuote>();

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                //Komento SQL:lle
                MySqlCommand cmd = new MySqlCommand("SELECT TuoteID, Tuotenimi, Yksikko, KplHinta FROM Tuote", conn);

                var dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    tuotteet.Add(new Tuote
                    {
                        TuoteID = dr.GetInt32("TuoteID"),
                        TuoteNimi = dr.GetString("Tuotenimi"),
                        Yksikko = dr.GetString("Yksikko"),
                        KplHinta = dr.GetFloat("KplHinta"),


                    });
                }

            }

            return tuotteet;
        }

        /// <summary>
        /// Hakee yksittäisen tuotteen nimen perusteella ja palauttaa tuotteen
        /// </summary>
        /// <param name="tuotenimi"></param>
        /// <returns></returns>
        public Tuote HaeTuote(string tuotenimi)
        {
            Tuote uusituote = null;

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {

                conn.Open();

                MySqlCommand cma = new MySqlCommand("SELECT * FROM tuote WHERE TuoteNimi = @tuotenimi", conn);
                cma.Parameters.AddWithValue("@Tuotenimi", tuotenimi);

                var dr = cma.ExecuteReader();

                if (dr.Read())
                {
                    uusituote = new Tuote
                    {
                        TuoteNimi = dr.GetString("TuoteNimi"),
                        KplHinta = dr.GetFloat("KplHinta"),
                        Yksikko = dr.GetString("Yksikko"),
                        TuoteID = dr.GetInt32("TuoteID")
                    };
                }

                return uusituote;
            }

        }

        /// <summary>
        /// Lisää tuotteen tietokantaan
        /// </summary>
        /// <param name="tuote"></param>
        public void LisaaTuote(Tuote tuote)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("INSERT INTO Tuote (Tuotenimi, Yksikko, KplHinta) VALUES (@Tuotenimi, @Yksikko, @KplHinta)", conn);

                cmd.Parameters.AddWithValue("@Tuotenimi", tuote.TuoteNimi);
                cmd.Parameters.AddWithValue("@Yksikko", tuote.Yksikko);
                cmd.Parameters.AddWithValue("@KplHinta", tuote.KplHinta);
                cmd.ExecuteNonQuery();

                MessageBox.Show($"Tuote {tuote.TuoteNimi} lisätty järjestelmään!");

            }

        }

        /// <summary>
        ///  Poistaa tuotteen tietokannasta
        /// </summary>
        /// <param name="tuote"></param>
        public void PoistaTuote(Tuote tuote)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("DELETE FROM Tuote WHERE TuoteID=@TuoteID", conn);

                cmd.Parameters.AddWithValue("@TuoteID", tuote.TuoteID);

                cmd.ExecuteNonQuery();

            }
        }

        /// <summary>
        /// Päivittää parametrinä saadun tuotteen tiedot tietokantaan.
        /// </summary>
        /// <param name="tuote"></param>
        public void MuokkaaTuotetta(Tuote tuote)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("UPDATE Tuote SET TuoteNimi=@Tuotenimi, Yksikko=@Yksikko, KplHinta = @KplHinta WHERE TuoteID=@TuoteID", conn);

                cmd.Parameters.AddWithValue("@TuoteID", tuote.TuoteID);
                cmd.Parameters.AddWithValue("@Tuotenimi", tuote.TuoteNimi);
                cmd.Parameters.AddWithValue("@Yksikko", tuote.Yksikko);
                cmd.Parameters.AddWithValue("@KplHinta", tuote.KplHinta);

                cmd.ExecuteNonQuery();

            }
        }

        /// <summary>
        /// Poistaa parametrinä saadun laskurivin tietokannasta
        /// </summary>
        /// <param name="rivi"></param>
        public void PoistaRivi(Laskurivi rivi)
        {
            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand("DELETE FROM Laskurivi WHERE RiviID=@RiviID", conn);

                cmd.Parameters.AddWithValue("@RiviID", rivi.RiviID);

                cmd.ExecuteNonQuery();

            }
        }

        /// <summary>
        /// Lisää rivin tietokantaan
        /// </summary>
        /// <param name="line"></param>
        public void LisaaRivi(Laskurivi line)
        {

            using (MySqlConnection conn = new MySqlConnection(localWithDb))
            {

                conn.Open();

                if (line.RiviID == 0)
                {
                    // LiSÄÄ RIVI JOS UUSI RIVI
                    MySqlCommand cmdIns = new MySqlCommand("INSERT INTO laskurivi (maara, laskuid, tuoteid, Rivihinta) VALUES(@maara, @laskuid, @tuoteid, @Rivihinta)", conn);
                    cmdIns.Parameters.AddWithValue("@maara", line.Maara);
                    cmdIns.Parameters.AddWithValue("@tuoteid", line.TuoteID);
                    cmdIns.Parameters.AddWithValue("@laskuid", line.LaskuID);
                    line.Rivihinta = line.KplHinta * line.Maara;
                    cmdIns.Parameters.AddWithValue("@Rivihinta", line.Rivihinta);

                    cmdIns.ExecuteNonQuery();
                }

                else
                {
                    // PAIVITA LASKURIVI
                    MySqlCommand cmdUpd = new MySqlCommand("UPDATE laskurivi SET maara = @maara, tuoteid=@tuoteid, Rivihinta=@Rivihinta WHERE RiviID=@RiviID", conn);
                    cmdUpd.Parameters.AddWithValue("@maara", line.Maara);
                    cmdUpd.Parameters.AddWithValue("@tuoteid", line.TuoteID);
                    cmdUpd.Parameters.AddWithValue("@RiviID", line.RiviID);
                    float Rivihinta = line.KplHinta * line.Maara;
                    cmdUpd.Parameters.AddWithValue("@Rivihinta", Rivihinta);
                    cmdUpd.ExecuteNonQuery();
                }
            }

        }
    }
}