﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace Harjoitustyo_LaskutusApp
{
    /// <summary>
    /// Interaction logic for HaeKaikkiAsiakkaat.xaml
    /// </summary>
    public partial class HaeKaikkiAsiakkaat : Window
    {

        private Hallintatyokalut tyokalu; // Luodaan muuttuja työkalu, joka viittaa luokkaan Hallintatyokalut

        public HaeKaikkiAsiakkaat()
        {
            InitializeComponent(); // Alustetaan käyttöliittymä

            tyokalu = new Hallintatyokalut(); // Alustetaan työkalu-luokka

            // Asetetaan comkaikkiasiakkaat, comAsiakasID ja comasnimi -comboboxien ItemSource-navigointiominaisuus käyttämään työkalun HaeAsiakkaat-metodia
            comkaikkiasiakkaat.ItemsSource = tyokalu.HaeAsiakkaat();
            comAsiakasID.ItemsSource = tyokalu.HaeAsiakkaat();
            comasnimi.ItemsSource = tyokalu.HaeAsiakkaat();

            var asiakkaat = tyokalu.HaeAsiakkaat();
            this.DataContext = asiakkaat[0]; // Asetetaan DataContext ensimmäisen asiakkaan tietoihin

            // Lisätään tapahtumankäsittelijät comAsiakasID- ja comasnimi -comboboxien SelectionChanged-tapahtumille
            comAsiakasID.SelectionChanged += ComAsiakasID_SelectionChanged;
            comasnimi.SelectionChanged += Comasnimi_SelectionChanged;
        }

        // Tapahtumankäsittelijä comAsiakasID-comboboxin valinnan muuttumiselle
        private void ComAsiakasID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comAsiakasID.SelectedItem != null)
            {
                var valittuAsiakas = (Asiakas)comAsiakasID.SelectedItem;
                comkaikkiasiakkaat.ItemsSource = new List<Asiakas> { valittuAsiakas }; // Asetetaan comkaikkiasiakkaat-comboboxin ItemSource-navigointiominaisuus valitun asiakkaan tiedoiksi
                comkaikkiasiakkaat.SelectedIndex = 0; // Asetetaan valituksi ensimmäinen alkio
            }
            else
            {
                comkaikkiasiakkaat.ItemsSource = tyokalu.HaeAsiakkaat(); // Asetetaan comkaikkiasiakkaat-comboboxin ItemSource-navigointiominaisuus kaikkien asiakkaiden tiedoiksi
            }
        }

        // Tapahhtumankäsittelyjä Comasnimi -comboboxin valinnan muuttumiselle.
        private void Comasnimi_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Kun asiakasvalikossa valitaan uusi asiakas, päivitetään kaikkiasiakkaat-valikko näyttämään vain valittu asiakas.
            if (comasnimi.SelectedItem != null)
            {
                var valittuAsiakas = (Asiakas)comasnimi.SelectedItem;
                comkaikkiasiakkaat.ItemsSource = new List<Asiakas> { valittuAsiakas };
                comkaikkiasiakkaat.SelectedIndex = 0;
            }
            // Jos asiakasta ei ole valittu, päivitetään kaikkiasiakkaat-valikko näyttämään kaikki asiakkaat.
            else
            {
                comkaikkiasiakkaat.ItemsSource = tyokalu.HaeAsiakkaat();
            }
        }

        /// <summary>
        /// Painikkeen toiminta asiakastiedon päivittämistä varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PaivitaValittuAsiakas(object sender, RoutedEventArgs e)
        {
            // Haetaan kaikkiasiakkaat-valikosta valittu asiakas.
            var asiakas = (Asiakas)comkaikkiasiakkaat.SelectedValue;

            if (asiakas != null)
            {
                // Avataan ikkuna asiakkaan päivittämistä varten.
                PaivitaAsiakas paivitettavaas = new PaivitaAsiakas(asiakas);
                var returnValue = paivitettavaas.ShowDialog();

                // Jos asiakkaan päivitys onnistui, päivitetään kaikkiasiakkaat-valikko.
                if (returnValue == true)
                {
                    comkaikkiasiakkaat.ItemsSource = tyokalu.HaeAsiakkaat();

                }
            }
        }

        /// <summary>
        /// Painikkeen toiminta asiakkaan poistamista varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PoistaValittuAsiakas(object sender, RoutedEventArgs e)
        {
            // Haetaan kaikkiasiakkaat-valikosta valittu asiakas.
            var asiakas = (Asiakas)comkaikkiasiakkaat.SelectedValue;

            if (asiakas != null)
            {
                 ObservableCollection<Lasku> aslaskut = tyokalu.HaeLaskutAsiakasIDlla(asiakas.AsiakasID);

                if (aslaskut.Count == 0)
                {
                    // Kysytään käyttäjältä varmistus ennen asiakkaan poistamista.
                    var result = MessageBox.Show("Haluatko varmasti poistaa valitun asiakkaan tiedot?", "Varoitus", MessageBoxButton.YesNo, MessageBoxImage.Question);

                    // Jos käyttäjä vahvistaa asiakkaan poiston, poistetaan asiakas ja päivitetään kaikkiasiakkaat-valikko.
                    if (result == MessageBoxResult.Yes)
                    {
                        tyokalu.PoistaAsiakas(asiakas);
                        comkaikkiasiakkaat.ItemsSource = tyokalu.HaeAsiakkaat();

                    }
                }

                else
                {
                    MessageBox.Show("Et voi poistaa asiakasta, jolla on laskuja järjestelmässä.", "Asiakasta ei voi poistaa");
                }

            }
        }

        /// <summary>
        /// Painikkeen toiminta asiakkaan lisäämistä varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LisaaUusiAsiakas(object sender, RoutedEventArgs e)
        {
            // Avataan ikkuna uuden asiakkaan lisäämistä varten.
            LisaaUusiAsiakas lisaaUusiAsiakas = new LisaaUusiAsiakas();
            var arvo = lisaaUusiAsiakas.ShowDialog();

            // Jos uuden asiakkaan lisääminen onnistui, päivitetään kaikkiasiakkaat-valikko.
            if (arvo == true)
            {
                comkaikkiasiakkaat.ItemsSource = tyokalu.HaeAsiakkaat();
            }

        }

        /// <summary>
        /// Painikkeen toiminta joka hakee kaikkien asiakkaiden tiedot datagridiin
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HaekaikkiAsiakkaat(object sender, RoutedEventArgs e)
        {
            // Päivitetään kaikkiasiakkaat-valikko hakemalla kaikkien asiakkaiden tiedot.
            comkaikkiasiakkaat.ItemsSource = tyokalu.HaeAsiakkaat();
        }

        /// <summary>
        /// Painikkeen toiminta
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Sulje_Ikkuna(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
