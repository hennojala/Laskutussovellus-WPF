﻿using System.Windows;
using System.Windows.Input;

namespace Harjoitustyo_LaskutusApp
{

    public partial class PaivitaAsiakas : Window
    {
        public PaivitaAsiakas(Asiakas asiakas)
        {
            InitializeComponent();
            // Asetetaan DataContextin arvoksi asiakasolio, jonka tietoja päivitetään.
            this.DataContext = asiakas;
        }

        /// <summary>
        /// Painikkeen kuuntelija asiakastietojen päivitystä varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PaivitaValittuAsiakas(object sender, RoutedEventArgs e)
        {
            // Haetaan DataContextista asiakasolio.
            var asiakas = (Asiakas)this.DataContext;

            // Luodaan uusi Hallintatyokalut-olio.
            var tyokalu = new Hallintatyokalut();

            // Kutsutaan Hallintatyokalut-olion metodia, joka päivittää asiakastietoja.
            tyokalu.MuokkaaAsiakasta(asiakas);

            // Näytetään ilmoitus, että asiakastietoja on päivitetty.
            MessageBox.Show("Asiakastieto päivitetty!");

            // Asetetaan DialogResult arvoksi true, jotta käyttöliittymä tietää että toiminto on suoritettu loppuun.
            DialogResult = true;
        }

        /// <summary>
        /// Tarkitaa että postinumero voi olla vain kokonaisluku
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PostinumeroTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Tarkista, onko syöte kokonaisluku
            if (!int.TryParse(e.Text, out int result))
            {
                // Jos ei ole, estä tekstin syöttö
                e.Handled = true;
            }
        }
    }
}
