﻿namespace Harjoitustyo_LaskutusApp
{
    // Tuote -luokka
    public class Tuote
    {
        public int RiviID { get; set; }
        public int TuoteID { get; set; }
        public string TuoteNimi { get; set; }
        public string Yksikko { get; set; }
        public float KplHinta { get; set; }
    }
}