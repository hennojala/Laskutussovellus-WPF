﻿using System.Windows;
using System.Windows.Input;

namespace Harjoitustyo_LaskutusApp
{

    public partial class LisaaUusiAsiakas : Window
    {
        public LisaaUusiAsiakas()
        {
            InitializeComponent();

            // Asetetaan DataContextin arvoksi uusi Asiakas-olio
            this.DataContext = new Asiakas();
        }

        /// <summary>
        /// Painikkeen tapahtumankuuntelija asiakkaan lisäämistä varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void LisataanAsiakas(object sender, RoutedEventArgs e)
        {
            // Haetaan DataContextin arvo (Asiakas-olio)
            var asiakas = (Asiakas)this.DataContext;

            // Luodaan uusi Hallintatyokalut-olio
            var tyokalu = new Hallintatyokalut();

            // Kutsutaan LisaaAsiakas-metodia, joka lisää uuden asiakkaan tietokantaan
            tyokalu.LisaaAsiakas(asiakas);

            // Asetetaan DialogResultin arvoksi true, jolloin ikkuna sulkeutuu
            DialogResult = true;
        }

        /// <summary>
        /// Tarkitaa että postinumero voi olla vain kokonaisluku
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PostinumeroTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Tarkista, onko syöte kokonaisluku
            if (!int.TryParse(e.Text, out int result))
            {
                // Jos ei ole, estä tekstin syöttö
                e.Handled = true;
            }
        }

    }
}
