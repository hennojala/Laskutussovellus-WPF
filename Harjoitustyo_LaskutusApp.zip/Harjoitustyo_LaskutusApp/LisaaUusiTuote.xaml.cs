﻿using System.Linq;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;

namespace Harjoitustyo_LaskutusApp
{
    /// <summary>
    /// Interaction logic for LisaaUusiTuote.xaml
    /// </summary>
    public partial class LisaaUusiTuote : Window
    {

        private Hallintatyokalut tyokalu;
        public LisaaUusiTuote()
        {
            InitializeComponent();

            // Asetetaan DataContext uuteen Tuote-olioon.
            this.DataContext = new Tuote();

            // Luodaan uusi Hallintatyokalut-olio.
            tyokalu = new Hallintatyokalut();
        }

        /// <summary>
        /// painikkeen kuuntelija tuotteen lisäämistä järjestelmään varten.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LisataanTuote(object sender, RoutedEventArgs e)
        {
            // Haetaan DataContextista Tuote-olio.
            var tuote = (Tuote)this.DataContext;

            // Luodaan uusi Hallintatyokalut-olio.
            var tyokalu = new Hallintatyokalut();
            // Lisätään Tuote-olio Hallintatyokalut-oliolle.
            tyokalu.LisaaTuote(tuote);

            // Asetetaan DialogResult arvoksi true, jotta käyttöliittymä tietää että painike on painettu.
            DialogResult = true;
        }

        // apumuuttuja, tarkistusta varten onko desimaalierotin jo käytetty vai ei
        private bool isDecimalUsed = false;

        /// <summary>
        /// Tapahtumankuuntelija estä käyttäjää syöttämästä epäkelpoja merkkejä ja muuttaa desimaaliluvuksi pilkusta tai pisteestä riippumatta.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LisaaYksikkohintaTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Tarkista, että syöte on numeroiden, pilkun tai pisteen yhdistelmä
            Regex regex = new Regex("[^0-9.,]+");
            if (regex.IsMatch(e.Text))
            {
                e.Handled = true;
            }
            else if (e.Text == ",")
            {
                // Jos käyttäjä syöttää pilkun, korvaa se pisteellä
                e.Handled = true;
                if (!isDecimalUsed)
                {
                    isDecimalUsed = true;
                    LisaaYksikkohintaTextBox.Text += ".";
                    LisaaYksikkohintaTextBox.CaretIndex = LisaaYksikkohintaTextBox.Text.Length;
                }
            }
            else if (e.Text == ".")
            {
                // Jos käyttäjä syöttää pisteen, tarkista, että se ei ole jo käytetty
                e.Handled = true;
                if (!isDecimalUsed)
                {
                    isDecimalUsed = true;
                    LisaaYksikkohintaTextBox.Text += ".";
                    LisaaYksikkohintaTextBox.CaretIndex = LisaaYksikkohintaTextBox.Text.Length;
                }
            }
            else
            {
                // Tarkista, että syöte sisältää vain yhden pilkun tai pisteen
                string text = LisaaYksikkohintaTextBox.Text + e.Text;
                int dotCount = text.Count(c => c == '.');
                int commaCount = text.Count(c => c == ',');
                if (dotCount + commaCount > 1)
                {
                    e.Handled = true;
                }
            }
        }
    }
}
