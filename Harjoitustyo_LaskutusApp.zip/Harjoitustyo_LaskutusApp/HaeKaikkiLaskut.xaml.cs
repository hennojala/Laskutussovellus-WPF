﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace Harjoitustyo_LaskutusApp
{
    /// <summary>
    /// Interaction logic for HaeKaikkiLaskut.xaml
    /// </summary>
    /// 
    public partial class HaeKaikkiLaskut : Window
    {

        // Otetaan käyttöön Hallintatyökalut-luokka ja luodaan uusi instanssi siitä.
        private Hallintatyokalut tyokalu;

        public HaeKaikkiLaskut()
        {
            // Luodaan uusi Hallintatyökalut-instanssi.
            tyokalu = new Hallintatyokalut();
            // Alustetaan käyttöliittymän komponentit.
            InitializeComponent();

            // Haetaan kaikki laskut ja asetetaan ne datagrid-komponentin ItemsSourceksi.
            dglaskut.ItemsSource = tyokalu.HaeKaikkiLaskut();
            // Asetetaan myös kaikki laskut valittaviksi ComboBox-komponentin ItemsSourceksi.
            comLaskuID.ItemsSource = tyokalu.HaeKaikkiLaskut();
            comAsLaskuID.ItemsSource = tyokalu.HaeKaikkiLaskutAsID();

            // Haetaan kaikki laskut uudelleen ja asetetaan ensimmäisen laskun tiedot DataContextiin.
            var laskut = tyokalu.HaeKaikkiLaskut();
            this.DataContext = laskut;

            // Liitetään SelectionChanged-tapahtumankäsittelijät ComboBox-komponentteihin ja DataGrid-komponenttiin.
            comLaskuID.SelectionChanged += ComLaskuID_SelectionChanged;
            comAsLaskuID.SelectionChanged += ComAsID_SelectionChanged;
            dglaskut.SelectionChanged += Dglaskut_SelectionChanged;

        }

        // Tapahtumankäsittelijä, joka suoritetaan kun asiakkaan ID-valinta ComboBoxissa muuttuu.
        private void ComAsID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comAsLaskuID.SelectedItem != null)
            {
                // Haetaan valittu asiakas ComboBoxista.
                var valittuAsiakas = (Lasku)comAsLaskuID.SelectedItem;
                // Haetaan kaikki laskut, joilla on sama AsiakasID kuin valitulla asiakkaalla.
                var laskut = tyokalu.HaeLaskutAsiakasIDlla(valittuAsiakas.AsiakasID);
                // Asetetaan DataGridin ItemsSourceksi haetut laskut ja valitaan ensimmäinen lasku.
                dglaskut.ItemsSource = laskut;
                dglaskut.SelectedIndex = 0;
            }
            else
            {
                // Jos ComboBoxista ei ole valittu mitään, näytetään kaikki laskut.
                dglaskut.ItemsSource = tyokalu.HaeKaikkiLaskut();
            }
        }

        // Tapahtumankäsittelijä, joka suoritetaan kun laskun ID-valinta ComboBoxissa muuttuu.
        private void ComLaskuID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comLaskuID.SelectedItem != null)
            {
                // Haetaan valittu lasku ComboBoxista.
                var valittuLasku = (Lasku)comLaskuID.SelectedItem;
                // Asetetaan DataGridin ItemsSourceksi valittu lasku ja valitaan se.
                dglaskut.ItemsSource = new List<Lasku> { valittuLasku };
                dglaskut.SelectedIndex = 0;
            }
            else
            {

                // Jos ComboBoxista ei ole valittu mitään, näytetään kaikki laskut.
                dglaskut.ItemsSource = tyokalu.HaeKaikkiLaskut();
            }
        }

        // Tapahtumankuuntelia laskulle, jota klikataan.
        private void Dglaskut_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Tarkistetaan onko valittu rivi null ja jos ei, niin mennään ifiin
            if (dglaskut.SelectedItem != null)
            {
                // Tarkistetaan, että valittu elementti on Lasku-olio
                if (dglaskut.SelectedItem is Lasku valittuLasku)
                {
                    // Muutetaan laskurivit näkyviin
                    dgRivit.Visibility = Visibility.Visible;
                    //Valitun laskun laskurivit näytetään
                    dgRivit.ItemsSource = valittuLasku.LaskuRivit;
                    // Muutetaan asiakastiedot näkyviin
                    asiakaspanel.Visibility = Visibility.Visible;
                    // Muutetaan valitun laskun asiakastiedot näkyviin
                    asiakaspanel.ItemsSource = valittuLasku.AsiakasTieto;

                    // Asetetaan valittuLasku DataContextiksi, jos se on eri kuin nykyinen DataContext
                    if (valittuLasku != this.DataContext)
                    {
                        this.DataContext = valittuLasku;
                    }
                }
                else
                {
                    // Jos valittu lasku ei ole Lasku-olio, poistetaan DataContext
                    this.DataContext = null;
                }
            }
            else
            {
                // Jos valittu rivi on null, poistetaan DataContext
                this.DataContext = null;
            }
        }


        /// <summary>
        /// Painikkeen toiminta laskun poistamista varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PoistaLasku_Click(object sender, RoutedEventArgs e)
        {
            Lasku valittuLasku = (Lasku)dglaskut.SelectedItem; //Haetaan valittu lasku DataGridistä

            if (valittuLasku != null)
            {
                // Haetaan varmistus käyttäjältä
                var result = MessageBox.Show("Haluatko varmasti poistaa valitun laskun järjestelmästä?", "Varoitus", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    //poista valittu lasku jos vastaus on kyllä
                    tyokalu.PoistaLasku(valittuLasku);

                    // Poista näkyvistä poistetun laskun laskurivit ja asiakastiedot ja hae kaikki laskut näkyviin
                    dgRivit.Visibility = Visibility.Collapsed;
                    asiakaspanel.Visibility = Visibility.Collapsed;
                    HaeKaikkiLaskut_Click(null, null);
                    dglaskut.ItemsSource = tyokalu.HaeKaikkiLaskut();

                }
            }
        }

        /// <summary>
        /// Painikkeen toiminta kaikkien laskujen hakemista varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void HaeKaikkiLaskut_Click(object sender, RoutedEventArgs e)
        {
            // Poista näkyvistä edellisen laskun laskurivit ja asiakastiedot ja hae kaikki laskut näkyviin
            dglaskut.ItemsSource = tyokalu.HaeKaikkiLaskut();
            dgRivit.Visibility = Visibility.Collapsed;
            asiakaspanel.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Painikkeen toiminta laskun lisäämiselle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LisaaLasku(object sender, RoutedEventArgs e)
        {
            // Luodaan uusi LisaaUusiLasku-ikkuna
            LisaaUusiLasku lisaaUusiLasku = new LisaaUusiLasku();
            // Avataan ikkuna ja tallennetaan, mitä käyttäjä teki (OK vai peruuta)
            var arvo = lisaaUusiLasku.ShowDialog();

            // Jos käyttäjä tallensi uuden laskun, päivitetään laskujen näkymä
            if (arvo == true)
            {
                dglaskut.ItemsSource = tyokalu.HaeKaikkiLaskut();
            }

            // Päivitetään myös muut näkymät
            HaeKaikkiLaskut_Click(null, null);
            dgRivit.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Painikkeen toiminta laskun päivittämistä varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PaivitaLasku(object sender, RoutedEventArgs e)
        {
            // Haetaan valittu lasku datagridista
            var lasku = (Lasku)dglaskut.SelectedValue;

            // Jos lasku löytyy, avataan uusi ikkuna laskun päivittämistä varten
            if (lasku != null)
            {
                PaivitaLasku paivitalas = new PaivitaLasku(lasku);
                paivitalas.ShowDialog();
            }

            // Päivitetään lopuksi näkymät
            HaeKaikkiLaskut_Click(null, null);
            dgRivit.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Painikkeen toiminta ikkunan sulkemista varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Sulje_Click(object sender, RoutedEventArgs e)
        {
            //Sulje ikkuna
            Close();
        }

        /// <summary>
        /// Painikkeen toiminta laskun "tulosta" varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TulostaLasku_Click(object sender, RoutedEventArgs e)
        {
            // Haetaan datagridin (dglaskut) valitun rivin Lasku-olio
            var lasku = (Lasku)dglaskut.SelectedValue;

            // Tarkistetaan, että Lasku-olio on olemassa
            if (lasku != null)
            {
                // Luodaan uusi TulostaLasku-ikkuna, joka ottaa Lasku-olion parametrina
                TulostaLasku tulostus = new TulostaLasku(lasku);

                // Avataan TulostaLasku-ikkuna
                tulostus.ShowDialog();
            }


        }
    }
}
