﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace Harjoitustyo_LaskutusApp
{
    /// <summary>
    /// Interaction logic for HaeKaikkiTuotteet.xaml
    /// </summary>
    public partial class HaeKaikkiTuotteet : Window
    {

        private Hallintatyokalut tyokalu;

        public HaeKaikkiTuotteet()
        {
            InitializeComponent();

            // Luodaan uusi hallintatyökalut-olio
            tyokalu = new Hallintatyokalut();

            // Haetaan kaikki tuotteet ja asetetaan ne comboboxeihin
            comkaikkituotteet.ItemsSource = tyokalu.HaeTuotteet();
            comtuotenimi.ItemsSource = tyokalu.HaeTuotteet();
            comTuoteID.ItemsSource = tyokalu.HaeTuotteet();

            // Asetetaan ensimmäinen tuote datanäkymän datakontekstiksi
            var tuotteet = tyokalu.HaeTuotteet();
            this.DataContext = tuotteet[0];

            // Kuunnellaan comboboxien valintojen muutoksia
            comtuotenimi.SelectionChanged += ComTuotenimi_SelectionChanged;
            comTuoteID.SelectionChanged += ComTuoteID_SelectionChanged;

        }

        /// <summary>
        /// Tapahtumankuuntelija tuotteen valitsemisessa TuoteID:n perusteella
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComTuoteID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comTuoteID.SelectedItem != null)
            {
                // Haetaan valittu tuote ID:n perusteella
                var valittutuote = (Tuote)comTuoteID.SelectedItem;

                // Asetetaan valittu tuote kaikki tuotteet comboboxiin
                comkaikkituotteet.ItemsSource = new List<Tuote> { valittutuote };
                comkaikkituotteet.SelectedIndex = 0;
            }
            else
            {
                // Jos mitään ei ole valittuna, palautetaan kaikki tuotteet comboboxiin
                comkaikkituotteet.ItemsSource = tyokalu.HaeTuotteet();
            }
        }

        /// <summary>
        /// Tapahtumankuuntelija tuotteen valitsesmisesta nimen perusteella
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComTuotenimi_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (comtuotenimi.SelectedItem != null)
            {
                // Haetaan valittu tuote nimen perusteella
                var valittutuote = (Tuote)comtuotenimi.SelectedItem;

                // Asetetaan valittu tuote kaikki tuotteet comboboxiin
                comkaikkituotteet.ItemsSource = new List<Tuote> { valittutuote };
                comkaikkituotteet.SelectedIndex = 0;
            }
            else
            {
                // Jos mitään ei ole valittuna, palautetaan kaikki tuotteet comboboxiin
                comkaikkituotteet.ItemsSource = tyokalu.HaeTuotteet();
            }
        }

        /// <summary>
        /// Painikkeen tapahtumankuuntelija valitun tuotteen päivittämistä varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PaivitaValittuTuote(object sender, RoutedEventArgs e)
        {
            // Valitaan käyttäjän valitsema tuote comkaikkituotteet:n SelectedValue -ominaisuudesta.
            var tuote = (Tuote)comkaikkituotteet.SelectedValue;

            if (tuote != null)
            {
                // Luodaan uusi PaivitaTuote -ikkuna käyttäen valittua tuotetta.
                PaivitaTuote paivitettavat = new PaivitaTuote(tuote);

                // Avataan ikkuna ja odotetaan käyttäjän toimintaa.
                var returnValue = paivitettavat.ShowDialog();

                // Jos käyttäjä painoi tallenna-nappia ikkunassa, päivitetään lista ja näytetään päivitetyt tiedot käyttäjälle.
                if (returnValue == true)
                {
                    comkaikkituotteet.ItemsSource = tyokalu.HaeTuotteet();
                }
            }
        }

        /// <summary>
        /// Painikkeen tapahtumankuuntelija tuotteen poistamista varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PoistaValittuTuote(object sender, RoutedEventArgs e)
        {
            // Valitaan käyttäjän valitsema tuote comkaikkituotteet:n SelectedValue -ominaisuudesta.
            var tuote = (Tuote)comkaikkituotteet.SelectedValue;

            if (tuote != null)
            {
                // Näytetään varoitusviesti käyttäjälle ennen tuotteen poistoa.
                var result = MessageBox.Show("Haluatko varmasti poistaa valitun tuotteen tiedot?", "Varoitus", MessageBoxButton.YesNo, MessageBoxImage.Question);

                // Jos käyttäjä valitsi kyllä, poistetaan tuote tietokannasta ja päivitetään lista.
                if (result == MessageBoxResult.Yes)
                {
                    tyokalu.PoistaTuote(tuote);
                    comkaikkituotteet.ItemsSource = tyokalu.HaeTuotteet();
                }
            }
        }

        /// <summary>
        /// Painikkeen tapahtumankuuntelija uuden tuotteen lisäämistä varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LisaaUusiTuote(object sender, RoutedEventArgs e)
        {
            // Luodaan uusi LisaaUusiTuote -ikkuna ja avataan se.
            LisaaUusiTuote lisaaUusiTuote = new LisaaUusiTuote();
            var arvo = lisaaUusiTuote.ShowDialog();

            // Jos käyttäjä painoi tallenna-nappia ikkunassa, päivitetään lista ja näytetään uusi tuote käyttäjälle.
            if (arvo == true)
            {
                comkaikkituotteet.ItemsSource = tyokalu.HaeTuotteet();
            }
        }

        /// <summary>
        /// Painikkeen tapahtumankuuntelija kaikkien tuotteiden hakua varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HaeTuotteita(object sender, RoutedEventArgs e)
        {
            // Päivitetään tuotelista näyttämällä kaikki tietokannan tuotteet.
            comkaikkituotteet.ItemsSource = tyokalu.HaeTuotteet();
        }

        /// <summary>
        /// Painikkeen tapahtumankuuntelija ikkunan sulkemista varten
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Sulje(object sender, RoutedEventArgs e)
        {
            // Sulje ikkuna
            Close();
        }
    }

}
